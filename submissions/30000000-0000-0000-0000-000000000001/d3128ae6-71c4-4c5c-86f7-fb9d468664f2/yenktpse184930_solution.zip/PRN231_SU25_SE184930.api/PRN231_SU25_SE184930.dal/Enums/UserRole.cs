﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PRN231_SU25_SE184930.dal.Enums
{
    public enum UserRole
    {
        Administrator = 5,
        Moderator = 6,
        Developer = 7,
        Member = 4
    }
}
