﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PRN231_SU25_SE184930.dal.DTOs
{
    public class LeopardTypeResponseDto
    {
        public int LeopardTypeId { get; set; }

        public string LeopardTypeName { get; set; }

        public string Origin { get; set; }

        public string Description { get; set; }
    }
}
