﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PRN231_SU25_SE184930.dal.DTOs
{
    public class ApiErrorResponse
    {
        public string ErrorCode { get; set; }
        public string Message { get; set; }
    }
}
