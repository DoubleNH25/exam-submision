﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repository.DTO
{
    public class LoginForm
    {
        public string email { get; set; }

        public string password { get; set; }
    }
}
